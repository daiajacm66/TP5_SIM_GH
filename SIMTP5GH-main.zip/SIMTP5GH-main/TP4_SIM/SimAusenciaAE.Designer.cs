﻿namespace TP4_SIM
{
    partial class SimAusenciaAE
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.txtOcupacionP = new System.Windows.Forms.TextBox();
            this.txtOcupacionAE = new System.Windows.Forms.TextBox();
            this.txtOcupacionV = new System.Windows.Forms.TextBox();
            this.txtOcupacionR = new System.Windows.Forms.TextBox();
            this.txtOcupacionE = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.txtEsperaP = new System.Windows.Forms.TextBox();
            this.txtEsperaAE = new System.Windows.Forms.TextBox();
            this.txtEsperaV = new System.Windows.Forms.TextBox();
            this.txtEsperaR = new System.Windows.Forms.TextBox();
            this.txtEsperaE = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.groupBox6.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.label21);
            this.groupBox6.Controls.Add(this.label22);
            this.groupBox6.Controls.Add(this.label23);
            this.groupBox6.Controls.Add(this.label24);
            this.groupBox6.Controls.Add(this.label25);
            this.groupBox6.Controls.Add(this.txtOcupacionP);
            this.groupBox6.Controls.Add(this.txtOcupacionAE);
            this.groupBox6.Controls.Add(this.txtOcupacionV);
            this.groupBox6.Controls.Add(this.txtOcupacionR);
            this.groupBox6.Controls.Add(this.txtOcupacionE);
            this.groupBox6.Controls.Add(this.label14);
            this.groupBox6.Controls.Add(this.label15);
            this.groupBox6.Controls.Add(this.label16);
            this.groupBox6.Controls.Add(this.txtEsperaP);
            this.groupBox6.Controls.Add(this.txtEsperaAE);
            this.groupBox6.Controls.Add(this.txtEsperaV);
            this.groupBox6.Controls.Add(this.txtEsperaR);
            this.groupBox6.Controls.Add(this.txtEsperaE);
            this.groupBox6.Controls.Add(this.label17);
            this.groupBox6.Controls.Add(this.label18);
            this.groupBox6.Controls.Add(this.label19);
            this.groupBox6.Controls.Add(this.label20);
            this.groupBox6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox6.Location = new System.Drawing.Point(220, 21);
            this.groupBox6.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox6.Size = new System.Drawing.Size(289, 474);
            this.groupBox6.TabIndex = 16;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Resultados";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(26, 408);
            this.label21.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(70, 17);
            this.label21.TabIndex = 20;
            this.label21.Text = "Postales";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(26, 381);
            this.label22.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(111, 17);
            this.label22.TabIndex = 19;
            this.label22.Text = "Atención emp.";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(26, 354);
            this.label23.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(58, 17);
            this.label23.TabIndex = 18;
            this.label23.Text = "Ventas";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(26, 327);
            this.label24.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(78, 17);
            this.label24.TabIndex = 17;
            this.label24.Text = "Reclamos";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(26, 301);
            this.label25.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(143, 17);
            this.label25.TabIndex = 16;
            this.label25.Text = "Envío de paquetes";
            // 
            // txtOcupacionP
            // 
            this.txtOcupacionP.Enabled = false;
            this.txtOcupacionP.Location = new System.Drawing.Point(172, 408);
            this.txtOcupacionP.Margin = new System.Windows.Forms.Padding(2);
            this.txtOcupacionP.Name = "txtOcupacionP";
            this.txtOcupacionP.Size = new System.Drawing.Size(94, 23);
            this.txtOcupacionP.TabIndex = 15;
            // 
            // txtOcupacionAE
            // 
            this.txtOcupacionAE.Enabled = false;
            this.txtOcupacionAE.Location = new System.Drawing.Point(172, 381);
            this.txtOcupacionAE.Margin = new System.Windows.Forms.Padding(2);
            this.txtOcupacionAE.Name = "txtOcupacionAE";
            this.txtOcupacionAE.Size = new System.Drawing.Size(94, 23);
            this.txtOcupacionAE.TabIndex = 14;
            // 
            // txtOcupacionV
            // 
            this.txtOcupacionV.Enabled = false;
            this.txtOcupacionV.Location = new System.Drawing.Point(172, 354);
            this.txtOcupacionV.Margin = new System.Windows.Forms.Padding(2);
            this.txtOcupacionV.Name = "txtOcupacionV";
            this.txtOcupacionV.Size = new System.Drawing.Size(94, 23);
            this.txtOcupacionV.TabIndex = 13;
            // 
            // txtOcupacionR
            // 
            this.txtOcupacionR.Enabled = false;
            this.txtOcupacionR.Location = new System.Drawing.Point(172, 327);
            this.txtOcupacionR.Margin = new System.Windows.Forms.Padding(2);
            this.txtOcupacionR.Name = "txtOcupacionR";
            this.txtOcupacionR.Size = new System.Drawing.Size(94, 23);
            this.txtOcupacionR.TabIndex = 12;
            // 
            // txtOcupacionE
            // 
            this.txtOcupacionE.Enabled = false;
            this.txtOcupacionE.Location = new System.Drawing.Point(172, 301);
            this.txtOcupacionE.Margin = new System.Windows.Forms.Padding(2);
            this.txtOcupacionE.Name = "txtOcupacionE";
            this.txtOcupacionE.Size = new System.Drawing.Size(94, 23);
            this.txtOcupacionE.TabIndex = 11;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(19, 262);
            this.label14.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(188, 17);
            this.label14.TabIndex = 10;
            this.label14.Text = "Porcentaje de ocupación";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(19, 41);
            this.label15.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(219, 17);
            this.label15.TabIndex = 9;
            this.label15.Text = "Tiempos de espera promedio";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(26, 193);
            this.label16.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(70, 17);
            this.label16.TabIndex = 4;
            this.label16.Text = "Postales";
            // 
            // txtEsperaP
            // 
            this.txtEsperaP.Enabled = false;
            this.txtEsperaP.Location = new System.Drawing.Point(172, 193);
            this.txtEsperaP.Margin = new System.Windows.Forms.Padding(2);
            this.txtEsperaP.Name = "txtEsperaP";
            this.txtEsperaP.Size = new System.Drawing.Size(76, 23);
            this.txtEsperaP.TabIndex = 8;
            // 
            // txtEsperaAE
            // 
            this.txtEsperaAE.Enabled = false;
            this.txtEsperaAE.Location = new System.Drawing.Point(172, 165);
            this.txtEsperaAE.Margin = new System.Windows.Forms.Padding(2);
            this.txtEsperaAE.Name = "txtEsperaAE";
            this.txtEsperaAE.Size = new System.Drawing.Size(76, 23);
            this.txtEsperaAE.TabIndex = 7;
            // 
            // txtEsperaV
            // 
            this.txtEsperaV.Enabled = false;
            this.txtEsperaV.Location = new System.Drawing.Point(172, 136);
            this.txtEsperaV.Margin = new System.Windows.Forms.Padding(2);
            this.txtEsperaV.Name = "txtEsperaV";
            this.txtEsperaV.Size = new System.Drawing.Size(76, 23);
            this.txtEsperaV.TabIndex = 6;
            // 
            // txtEsperaR
            // 
            this.txtEsperaR.Enabled = false;
            this.txtEsperaR.Location = new System.Drawing.Point(172, 109);
            this.txtEsperaR.Margin = new System.Windows.Forms.Padding(2);
            this.txtEsperaR.Name = "txtEsperaR";
            this.txtEsperaR.Size = new System.Drawing.Size(76, 23);
            this.txtEsperaR.TabIndex = 5;
            // 
            // txtEsperaE
            // 
            this.txtEsperaE.Enabled = false;
            this.txtEsperaE.Location = new System.Drawing.Point(172, 82);
            this.txtEsperaE.Margin = new System.Windows.Forms.Padding(2);
            this.txtEsperaE.Name = "txtEsperaE";
            this.txtEsperaE.Size = new System.Drawing.Size(76, 23);
            this.txtEsperaE.TabIndex = 4;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(26, 165);
            this.label17.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(111, 17);
            this.label17.TabIndex = 3;
            this.label17.Text = "Atención emp.";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(26, 136);
            this.label18.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(58, 17);
            this.label18.TabIndex = 2;
            this.label18.Text = "Ventas";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(26, 109);
            this.label19.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(78, 17);
            this.label19.TabIndex = 1;
            this.label19.Text = "Reclamos";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(26, 82);
            this.label20.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(143, 17);
            this.label20.TabIndex = 0;
            this.label20.Text = "Envío de paquetes";
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(9, 51);
            this.button1.Margin = new System.Windows.Forms.Padding(2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(190, 41);
            this.button1.TabIndex = 15;
            this.button1.Text = "INICIAR SIMULACIÓN";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.simularAusenciaAE);
            // 
            // SimAusenciaAE
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(529, 527);
            this.Controls.Add(this.groupBox6);
            this.Controls.Add(this.button1);
            this.Name = "SimAusenciaAE";
            this.Text = "SimAusenciaAE";
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.TextBox txtOcupacionP;
        private System.Windows.Forms.TextBox txtOcupacionAE;
        private System.Windows.Forms.TextBox txtOcupacionV;
        private System.Windows.Forms.TextBox txtOcupacionR;
        private System.Windows.Forms.TextBox txtOcupacionE;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox txtEsperaP;
        private System.Windows.Forms.TextBox txtEsperaAE;
        private System.Windows.Forms.TextBox txtEsperaV;
        private System.Windows.Forms.TextBox txtEsperaR;
        private System.Windows.Forms.TextBox txtEsperaE;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Button button1;
    }
}