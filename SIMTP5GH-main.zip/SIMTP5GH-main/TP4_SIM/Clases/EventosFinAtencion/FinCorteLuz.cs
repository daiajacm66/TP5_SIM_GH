﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TP4_SIM.Clases.EventosFinAtencion
{
    public class FinCorteLuz
    {
        private double t;
        private double finEnfriamiento;

        public double T { get => t; set => t = value; }
        public double FinAtencion { get => finEnfriamiento; set => finEnfriamiento = value; }
    }
    }
