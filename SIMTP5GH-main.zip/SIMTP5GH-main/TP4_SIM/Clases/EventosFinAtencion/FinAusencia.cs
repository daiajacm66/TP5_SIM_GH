﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TP4_SIM.Clases.EventosFinAtencion
{
    public class FinAusencia
    {
        private double fin;

        public double Fin { get => fin; set => fin = value; }
    }
}
