﻿namespace TP4_SIM
{
    partial class Resultados
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Resultados));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txtEsperaE = new System.Windows.Forms.TextBox();
            this.txtEsperaR = new System.Windows.Forms.TextBox();
            this.txtEsperaV = new System.Windows.Forms.TextBox();
            this.txtEsperaAE = new System.Windows.Forms.TextBox();
            this.txtEsperaP = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.txtOcupacionP = new System.Windows.Forms.TextBox();
            this.txtOcupacionAE = new System.Windows.Forms.TextBox();
            this.txtOcupacionV = new System.Windows.Forms.TextBox();
            this.txtOcupacionR = new System.Windows.Forms.TextBox();
            this.txtOcupacionE = new System.Windows.Forms.TextBox();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txtOcupacionP);
            this.groupBox1.Controls.Add(this.txtOcupacionAE);
            this.groupBox1.Controls.Add(this.txtOcupacionV);
            this.groupBox1.Controls.Add(this.txtOcupacionR);
            this.groupBox1.Controls.Add(this.txtOcupacionE);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.txtEsperaP);
            this.groupBox1.Controls.Add(this.txtEsperaAE);
            this.groupBox1.Controls.Add(this.txtEsperaV);
            this.groupBox1.Controls.Add(this.txtEsperaR);
            this.groupBox1.Controls.Add(this.txtEsperaE);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(53, 39);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(553, 217);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Punto 1";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(34, 61);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(120, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "Envío de paquetes";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(34, 88);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(69, 16);
            this.label2.TabIndex = 1;
            this.label2.Text = "Reclamos";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(34, 117);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(49, 16);
            this.label3.TabIndex = 2;
            this.label3.Text = "Ventas";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(34, 148);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(92, 16);
            this.label4.TabIndex = 3;
            this.label4.Text = "Atención emp.";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(34, 177);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(60, 16);
            this.label5.TabIndex = 4;
            this.label5.Text = "Postales";
            // 
            // txtEsperaE
            // 
            this.txtEsperaE.Enabled = false;
            this.txtEsperaE.Location = new System.Drawing.Point(179, 61);
            this.txtEsperaE.Name = "txtEsperaE";
            this.txtEsperaE.Size = new System.Drawing.Size(100, 22);
            this.txtEsperaE.TabIndex = 4;
            // 
            // txtEsperaR
            // 
            this.txtEsperaR.Enabled = false;
            this.txtEsperaR.Location = new System.Drawing.Point(179, 89);
            this.txtEsperaR.Name = "txtEsperaR";
            this.txtEsperaR.Size = new System.Drawing.Size(100, 22);
            this.txtEsperaR.TabIndex = 5;
            // 
            // txtEsperaV
            // 
            this.txtEsperaV.Enabled = false;
            this.txtEsperaV.Location = new System.Drawing.Point(179, 117);
            this.txtEsperaV.Name = "txtEsperaV";
            this.txtEsperaV.Size = new System.Drawing.Size(100, 22);
            this.txtEsperaV.TabIndex = 6;
            // 
            // txtEsperaAE
            // 
            this.txtEsperaAE.Enabled = false;
            this.txtEsperaAE.Location = new System.Drawing.Point(179, 145);
            this.txtEsperaAE.Name = "txtEsperaAE";
            this.txtEsperaAE.Size = new System.Drawing.Size(100, 22);
            this.txtEsperaAE.TabIndex = 7;
            // 
            // txtEsperaP
            // 
            this.txtEsperaP.Enabled = false;
            this.txtEsperaP.Location = new System.Drawing.Point(179, 171);
            this.txtEsperaP.Name = "txtEsperaP";
            this.txtEsperaP.Size = new System.Drawing.Size(100, 22);
            this.txtEsperaP.TabIndex = 8;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(25, 29);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(213, 16);
            this.label6.TabIndex = 9;
            this.label6.Text = "Tiempos de espera promedio";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(328, 29);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(180, 16);
            this.label7.TabIndex = 10;
            this.label7.Text = "Porcentaje de ocupación";
            // 
            // txtOcupacionP
            // 
            this.txtOcupacionP.Enabled = false;
            this.txtOcupacionP.Location = new System.Drawing.Point(356, 171);
            this.txtOcupacionP.Name = "txtOcupacionP";
            this.txtOcupacionP.Size = new System.Drawing.Size(124, 22);
            this.txtOcupacionP.TabIndex = 15;
            // 
            // txtOcupacionAE
            // 
            this.txtOcupacionAE.Enabled = false;
            this.txtOcupacionAE.Location = new System.Drawing.Point(356, 145);
            this.txtOcupacionAE.Name = "txtOcupacionAE";
            this.txtOcupacionAE.Size = new System.Drawing.Size(124, 22);
            this.txtOcupacionAE.TabIndex = 14;
            // 
            // txtOcupacionV
            // 
            this.txtOcupacionV.Enabled = false;
            this.txtOcupacionV.Location = new System.Drawing.Point(356, 117);
            this.txtOcupacionV.Name = "txtOcupacionV";
            this.txtOcupacionV.Size = new System.Drawing.Size(124, 22);
            this.txtOcupacionV.TabIndex = 13;
            // 
            // txtOcupacionR
            // 
            this.txtOcupacionR.Enabled = false;
            this.txtOcupacionR.Location = new System.Drawing.Point(356, 89);
            this.txtOcupacionR.Name = "txtOcupacionR";
            this.txtOcupacionR.Size = new System.Drawing.Size(124, 22);
            this.txtOcupacionR.TabIndex = 12;
            // 
            // txtOcupacionE
            // 
            this.txtOcupacionE.Enabled = false;
            this.txtOcupacionE.Location = new System.Drawing.Point(356, 61);
            this.txtOcupacionE.Name = "txtOcupacionE";
            this.txtOcupacionE.Size = new System.Drawing.Size(124, 22);
            this.txtOcupacionE.TabIndex = 11;
            // 
            // Resultados
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(681, 493);
            this.Controls.Add(this.groupBox1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Resultados";
            this.Text = "Resultados";
            this.Load += new System.EventHandler(this.Resultados_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txtEsperaP;
        private System.Windows.Forms.TextBox txtEsperaAE;
        private System.Windows.Forms.TextBox txtEsperaV;
        private System.Windows.Forms.TextBox txtEsperaR;
        private System.Windows.Forms.TextBox txtEsperaE;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtOcupacionP;
        private System.Windows.Forms.TextBox txtOcupacionAE;
        private System.Windows.Forms.TextBox txtOcupacionV;
        private System.Windows.Forms.TextBox txtOcupacionR;
        private System.Windows.Forms.TextBox txtOcupacionE;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
    }
}